import numpy as np
from scipy.interpolate import griddata

class steam:

    def __init__(self, pressure, T=None, x=None, v=None, h=None, s=None, name=None):
        self.p = pressure # pressure kPa
        self.T = T # Temperature - degrees C
        self.x = x # quality (a value between e and 1)
        self.v = v # specific volume - m^3/kg
        self.h = h # enthalpy kJ/kg
        self.s = s # entropy - kJ/(kg K)
        self.name = name # a useful identifier
        self.region = None # 'superheated' or 'saturated
        if T==None and x==None and v==None and h==None and s==None: return
        else: self.calc()

    def calc(self):
        # Calculate remaining unknown state properties
        # Assume we are in the saturated ... until proven differently!

        # Read the saturated table data
        tscol, pscol, hfcol, hgcol, \
        sfcol, sgcol, vfcol, vgcol = \
            np.loadtxt('sat_water_table.txt', skiprows=1, unpack=True)

        # Using the known pressure, interpolate on the saturation tables columns
        # at the known pressure
        sfval = float(griddata(pscol, sfcol, self.p/100))
        sgval = float(griddata(pscol, sgcol, self.p/100))
        vfval = float (griddata(pscol, vfcol, self.p/100))
        vgval = float(griddata(pscol, vgcol, self.p/100))
        hfval = float(griddata(pscol, hfcol, self.p/100))
        hgval = float(griddata(pscol, hgcol, self.p/100))
        tsat = float(griddata(pscol, tscol, self.p/100))

        if self.T is not None:  # then temperature determines the region
            if self.T > tsat: # then Superheated
                self.region = 'superheated'
            elif self.T <= tsat: # then subcooled region
                raise ValueError('This function cannot operate in the subcooled region')
            else:
                raise ValueError('Not enough properties given (Psat and Tsat)')
        elif self.h is not None:
            self.x = (self.h - hfval) / (hgval - hfval)
        elif self.s is not None:
            self.x = (self.s - sfval) / (sgval - sfval)
        elif self.v is not None:
            self.x = (self.v - vfval) / (vgval - vfval)

        if self.x is not None: # x (quality) is known
            if self.x < 0:
                raise ValueError('Error - this function cannot operate in the sub-cooled region')
            elif self.x <= 1.001: # 1.001 handles the GAP betiween the Sat and Super regions in the
                # now we know that we are in the SATURATED region
                self.h = hfval + self.x * (hgval - hfval)
                self.s = sfval + self.x * (sgval - sfval)
                self.v = vfval + self.x * (vgval - vfval)
                self.T = float(tsat)
                self.T = float(tsat)
                self.region = 'saturated'
                return None

        # since we haven't returned yet, we must be superheated
        # now we know we are in the superheated region ....

        tcol, hcol,scol,pcol = np.loadtxt('superheated_water_table.txt',
                                          skiprows = 1, unpack = True)
        if self.T is not None: #Temperature is known, so calculate h and s
            self.h = float(griddata((tcol, pcol), hcol,  (self.T, self.p)))
            self.s = float(griddata( (tcol, pcol), scol, (self.T, self.p)))
        elif self.h is not None: #h is known, so calculate T and s
            self.T = float(griddata((hcol, pcol), tcol, (self.h, self.p)))
            self.s = float(griddata((hcol, pcol), scol, (self.h, self.p)))
        elif self.s is not None: #s is known, so calculate T and h
            self.T = float(griddata((scol, pcol), tcol, (self.s, self.p)))
            self.h = float(griddata( (scol, pcol), hcol, (self.s, self.p)))
        else:
            raise ValueError('Not enough properties specified in the superheated region')
        #endif:

        self.x=None
        self.v=None
        self.region = "superheated"

        return None

    def print (self):
        if self.name is not None:
            print('Name: {:s}'.format(self.name))
        if self.region is not None:
            print('Region: {:s}'.format(self.region))
        if self.p is not None:
            print('p {:.2f} kPa'.format(self.p))
        if self.T is not None:
            print('T = {:.1f} degrees C'.format(self.T))
        if self.h is not None:
            print('h = {:.2f} kJ/kg'.format(self.h))
        if self.s is not None:
            print('s = {:.4f} kJ/(kg K)'.format(self.s))
        if self.v is not None:
            print ('v = {:.6f} m^3/kg'. format(self.v))
        if self.x is not None:
            print('x = {:.4f}'.format(self.x))
        print('')



def main():

    inlet = steam(7350, name='Turbine Inlet') #not enough information to calculate
    inlet.x =0.9 # 90 percent quality - modified DIRECTLY - not through a method
    inlet.calc() #now there is enough information
    inlet.print()
    h1 = inlet.h # read directly - not through a method
    s1 = inlet.s
    print(h1, s1, '\n')

    outlet=steam(100, s = inlet.s, name='Turbine Exit')
        #notice - S=inlet.s
    outlet.print()

    another=steam(8575, h=2050, name='State 3')
    another.print()

    yetanother=steam(8575, h=3125, name='State 4')
    yetanother.print()

if __name__ == "__main__":
    main()