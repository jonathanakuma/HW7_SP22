import sys
from PyQt5 import QtWidgets as Qtw
from Rankine import rankine
from Steam import steam
from RankineGui import Ui_Form

class MainWindow(Qtw.QWidget,Ui_Form):
    def __int__(self):
    #  main window constructor
        super(main_window,self).__init__()
        self.setupUi(self)

    # Main UI code Goes here
        self.rankine=rankine(p_low)
        self.PLow=float(self.le_PLow.text())
        self.PHigh=float(self.le_PHigh.text())
        self.rdo_Quality.clicked.connect(self.setQualityOrTHigh())
        self.rdo_THigh.clicked.connect(self.setQualityOrTHigh())
        self.TurbineInlet= float(self.le_TurbineInletCondition.text())
        self.TurbineEff = float(self.le_TurbineEff.text())
        self.rankine = rankine(self.PLow, self.PHigh, self.TurbineEff)
        self.btn_Calculate.clicked.connect(self.calcRankine)
        self.le_PHigh.editingFinished.connect(self.setPHigh)
        self.le_PLow.editingFinished.connect(self.setPLow)
        self.setPHigh()
        self.setPLow()
        self.setQualityOrTHigh()
        self.calcRankine()
        self.show()

        #self.TurbineEff = self.lbl_Turbine_eff
     #   self.btn_Calculate.clicked.connect(self.calc_efficiency())
        self.show()

    def setPHigh(self):
        s1 = steam(self.PLow)
        Tsat, hf, hg, sf, sg, vf, vg = s2.getSatProperties()
        PHighSatProps = 'Psat ={:0.2f} bar, TSat = {:0.2f} C'.format(self.PLow, self.Tsat)
        PHighSatProps += '\nhf = {:0.2f} kJ/kg, hg = {:0.2f} kJ/kg'.format(hf,hg)
        PHighSatProps += '\nhf = {:0.2f} kJ/kg*K, sg = {:0.2f} kJ/kg*K'.format(sf, sg)
        PHighSatProps += '\nhf = {:0.2f} m^3/kg, vg = {:0.2f} m^3/kg'.format(vf, vg)
        self.lbl_SatPropHigh.setText(PHighSatProps)

    def setPlow(self):
        s2 = steam(self.PLow)
        self.Tsat, hf, hg, sf, sg, vf, vg = s2.getSatProperties()
        PLowSatProps = 'Psat ={:0.2f} bar, TSat = {:0.2f} C'.format(self.Plow, self.Tsat)
        PLowSatProps += '\nhf = {:0.2f} kJ/kg, hg = {:0.2f} kJ/kg'.format(hf,hg)
        PLowSatProps += '\nhf = {:0.2f} kJ/kg*K, sg = {:0.2f} kJ/kg*K'.format(sf, sg)
        PLowSatProps += '\nhf = {:0.2f} m^3/kg, vg = {:0.2f} m^3/kg'.format(vf, vg)
        self.lbl_SatPropLow.setText(PLowSatProps)

    def setQualityOrTHigh(self):
        if self.rdo_Quality.isChecked():
            self.le_TurbineInletCondition.setText('1')
        else:
            self.le_TurbineInletCondition.setText(str(self.Tsat + 1))

    def calcRankine(self, rankinef):
        if self.rdo_Quality.isChecked():
            self.Quality = 1
            self.THigh = None
        if self.rdo_THigh.isChecked():
            self.THigh = float(self.le_TurbineInletCondition.text())
            self.Quality = None
        r1 = rankine(p_low=self.PLow*100, p_high=self.PHigh*100, t_high=self.THigh, eff_turbine=self.Turbine_eff)
        H1, H2, H3, H4, self.turbine_work, self.pump_work, self.heat_added, self.efficiency = r1.calc_efficiency()

#if this module is being imported, this won't run.  If it is the main module, it will run.
if __name__ == '__main__':
    app = Qtw.QApplication(sys.argv)
    mw = MainWindow()
    mw.setWindowTitle('Rankin Cycle Calculator')
    sys.exit(app.exec())

